------------------------------------------------------
  HOW TO CREATE A THEME OR INSTALL A THEME :
------------------------------------------------------
 
Each Theme is its own directory inside the folder
named "themes" in you CRAFTY SYNTAX Installation.
Installing a new theme is just simply uploading
a new folder. 
 
 All themes that have been created for CRAFTY SYNTAX 
 have been uploaded to the website at:
 
 https://lupopedia.com/templates.php
 
 before clicking the above link you need to be
 logged into your account. A really easy way to
 do this is to log into your live help admin and 
 in the overview index page click on "member services" 
 

