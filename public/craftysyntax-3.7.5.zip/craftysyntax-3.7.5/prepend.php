<?php

// For some odd reason that is beyond me some servers require this file
// to exist.. Any Idea why???

// prepend.php

?>