<?php
  $color_background="F7FAFF";
  $color_alt1 = "E3EAFC";
  $color_alt2 = "C7DEFF";    
  $color_alt3 = "E5ECF4";  
  $color_alt4 = "C4CAE4";
?>