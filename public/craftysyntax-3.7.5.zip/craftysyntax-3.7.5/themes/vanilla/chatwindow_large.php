<html>
<body  marginheight=0 marginwidth=0 leftmargin=0 topmargin=0 bgcolor=<?php echo $botbackcolor; ?> background="<?php echo $botbackground; ?>">

<link rel="stylesheet" type="text/css" href="themes/vanilla/chatbubble.css"   />	


<DIV style="background: #FFFFFF url('<?php echo $topbackground; ?>'); width:100%; height:<?php echo $topframeheight; ?>px; top:0px; left:0px; position:relative;">
  	


  <DIV style="float:right; width:300px; height:<?php echo $topframeheight; ?>px; text-align:right;  "><?php echo $cslhdue; ?></DIV>    

</DIV>    
 
 	<?php if(!(empty($td_list))){ ?>
				<DIV style="width:100%; height:28px; background: #FFFFFF url('themes/vanilla/topbar.png'); position:relative;">
  <div id="navigation" style="float:left; height:28px;">
    <?php echo $td_list; ?>
 </div>
</div>
	<div style="margin: 0; padding: 0; clear: both;"></div>
	
<?php } ?>
 
<DIV style="background: <?php echo $midbackcolor; ?>; width:99%; height:315px; top:0px; left:4px; position:relative; border: #999999 1px solid;">
			<?php if(!(empty($htmlcode))){ echo $htmlcode; } else { ?>
	    <iframe height="315" width="99%" frameborder=0 src="<?php echo $urlforchat; ?>" name="chatwindow" scrolling="auto" border="0" marginheight="0" marginwidth="0" NORESIZE=NORESIZE></iframe>
	  <?php } ?>
</DIV> 
	
 

</body>
</html>