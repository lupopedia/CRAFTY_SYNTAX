<?php
if(empty($winwidth)){ $winwidth = 650; }  
if(empty($winheight)){ $winheight = 480; }  
?>