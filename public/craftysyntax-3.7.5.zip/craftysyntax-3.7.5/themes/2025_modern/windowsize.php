<?php
if (empty($winwidth)) { $winwidth = 640; }
if (empty($winheight)) { $winheight = 520; }
?>

